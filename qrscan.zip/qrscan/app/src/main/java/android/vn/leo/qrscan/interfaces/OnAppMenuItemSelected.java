package android.vn.leo.qrscan.interfaces;

public interface OnAppMenuItemSelected {

    void onHomeSelected();

    void onSettingSelected();

    void onRatingSelected();

    void onSharingSelected();

    void onAboutSelected();

    void onExitSelected();
}
