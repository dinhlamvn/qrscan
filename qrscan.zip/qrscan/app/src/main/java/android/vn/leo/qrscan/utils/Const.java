package android.vn.leo.qrscan.utils;

public final class Const {

    public static final int TIME_TO_REMOVE_RESULT = 3 * 1000;

    public static final String PRODUCT_RESEARCH_URL = "https://www.google.com/search?source=lnms&tbm=shop&q=";
}
