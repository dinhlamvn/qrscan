package android.vn.leo.qrscan.interfaces;

public interface IDialogCallback {

    void onAction1();
    void onAction2();
    void onAction3();
    void onActionCancel();
}
